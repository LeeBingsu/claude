$clear @s $(item) $(count)
